import About from "./compo/about";
import Home from "./compo/page";


function App() {
  return (
    <div>
      <Home/>
    </div>
  );
}

export default App;
